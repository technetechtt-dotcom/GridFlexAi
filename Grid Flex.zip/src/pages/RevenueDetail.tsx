import React from 'react';
import { ArrowLeft, DollarSign, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer } from
'recharts';
import { Page } from '../components/Sidebar';
interface RevenueDetailProps {
  onNavigate: (page: Page) => void;
}
const mockRevenueData = [
{
  time: '00:00',
  value: 50
},
{
  time: '04:00',
  value: 45
},
{
  time: '08:00',
  value: 120
},
{
  time: '12:00',
  value: 350
},
{
  time: '16:00',
  value: 280
},
{
  time: '20:00',
  value: 150
},
{
  time: '23:59',
  value: 60
}];

export function RevenueDetail({ onNavigate }: RevenueDetailProps) {
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex items-center space-x-4 mb-6">
        <button
          onClick={() => onNavigate('dashboard')}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors">

          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Revenue Analysis
          </h2>
          <p className="text-slate-400">
            Financial performance and projections
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Revenue Today</span>
            <DollarSign className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">R2.4M</div>
          <div className="text-sm text-emerald-400 mt-1">
            +R150k vs forecast
          </div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Avg Price / MWh</span>
            <TrendingUp className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">R1,250</div>
          <div className="text-sm text-slate-500 mt-1">Peak: R3,500</div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Projected (Month)</span>
            <DollarSign className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">R72.5M</div>
          <div className="text-sm text-emerald-400 mt-1">On track</div>
        </div>
      </div>

      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        className="bg-slate-800 border border-slate-700 rounded-xl p-6">

        <h3 className="text-lg font-semibold text-slate-100 mb-6">
          Intraday Revenue Profile
        </h3>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockRevenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
                vertical={false} />

              <XAxis
                dataKey="time"
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false} />

              <YAxis
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `R${val}k`} />

              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  color: '#f1f5f9'
                }}
                itemStyle={{
                  color: '#f1f5f9'
                }}
                formatter={(val) => [`R${val}k`, 'Revenue']} />

              <Area
                type="monotone"
                dataKey="value"
                stroke="#10b981"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorRevenue)" />

            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>);

}