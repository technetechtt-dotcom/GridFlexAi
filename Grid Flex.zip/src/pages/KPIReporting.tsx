import React, { useState, createElement } from 'react';
import { motion } from 'framer-motion';
import { Download, Calendar, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { Page } from '../components/Sidebar';
import { auditLogger } from '../lib/auditLogger';
import { useAuth } from '../context/AuthContext';
interface KPIReportingProps {
  onNavigate: (page: Page) => void;
}
const mockPerformanceData = [
{
  month: 'Jan',
  revenue: 4.2,
  curtailment: 3.5,
  accuracy: 92
},
{
  month: 'Feb',
  revenue: 3.8,
  curtailment: 4.2,
  accuracy: 94
},
{
  month: 'Mar',
  revenue: 4.5,
  curtailment: 2.8,
  accuracy: 95
},
{
  month: 'Apr',
  revenue: 4.1,
  curtailment: 3.1,
  accuracy: 93
},
{
  month: 'May',
  revenue: 4.8,
  curtailment: 2.5,
  accuracy: 96
},
{
  month: 'Jun',
  revenue: 5.2,
  curtailment: 1.8,
  accuracy: 97
}];

export function KPIReporting({ onNavigate }: KPIReportingProps) {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState('YTD');
  const handleExport = () => {
    // Generate CSV content
    const headers = ['Month', 'Revenue (M)', 'Curtailment (%)', 'Accuracy (%)'];
    const rows = mockPerformanceData.map((d) =>
    [d.month, d.revenue, d.curtailment, d.accuracy].join(',')
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    // Create download link
    const blob = new Blob([csvContent], {
      type: 'text/csv'
    });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kpi-report-${timeRange.toLowerCase()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    // Audit log
    if (user) {
      auditLogger.log('EXPORT_KPI_REPORT', user.id, {
        timeRange
      });
    }
  };
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-100">KPI & Reporting</h2>
          <p className="text-slate-400">
            Performance tracking and financial analytics
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="bg-slate-800 p-1 rounded-lg border border-slate-700 flex space-x-1">
            {['7d', '30d', '90d', 'YTD'].map((range) =>
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${timeRange === range ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700'}`}>

                {range}
              </button>
            )}
          </div>
          <button
            onClick={handleExport}
            className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">

            <Download className="w-4 h-4 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
        {
          label: 'Total Revenue',
          value: 'R26.6M',
          change: '+12%',
          trend: 'up',
          target: 'revenue-detail' as Page
        },
        {
          label: 'Avg Curtailment',
          value: '2.9%',
          change: '-1.5%',
          trend: 'down',
          target: 'curtailment-detail' as Page
        },
        {
          label: 'Forecast Accuracy',
          value: '94.5%',
          change: '+0.8%',
          trend: 'up',
          target: 'forecast-accuracy' as Page
        },
        {
          label: 'Battery Cycles',
          value: '142',
          change: '+15',
          trend: 'neutral',
          target: 'dispatch-status' as Page
        }].
        map((stat, i) =>
        <div
          key={i}
          onClick={() => onNavigate(stat.target)}
          className="bg-slate-800 border border-slate-700 rounded-xl p-5 cursor-pointer hover:border-slate-600 transition-colors group">

            <p className="text-sm text-slate-400 font-medium mb-1 group-hover:text-slate-300 transition-colors">
              {stat.label}
            </p>
            <div className="flex items-end justify-between">
              <h3 className="text-2xl font-bold text-slate-100">
                {stat.value}
              </h3>
              <div
              className={`flex items-center text-xs font-medium px-2 py-1 rounded-full ${
              stat.trend === 'up' ?
              'bg-emerald-500/10 text-emerald-400' :
              stat.trend === 'down' ?
              'bg-emerald-500/10 text-emerald-400' :
              // Down is good for curtailment, handled simply here
              'bg-slate-700 text-slate-300'}`
              }>

                {stat.trend === 'up' ?
              <ArrowUpRight className="w-3 h-3 mr-1" /> :

              <ArrowDownRight className="w-3 h-3 mr-1" />
              }
                {stat.change}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          onClick={() => onNavigate('revenue-detail')}
          className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors">

          <h3 className="text-lg font-semibold text-slate-100 mb-6">
            Revenue Performance (ZAR Millions)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockPerformanceData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#334155"
                  vertical={false} />

                <XAxis
                  dataKey="month"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <YAxis
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <Tooltip
                  cursor={{
                    fill: '#334155',
                    opacity: 0.2
                  }}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f1f5f9'
                  }} />

                <Bar
                  dataKey="revenue"
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                  name="Revenue" />

              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Curtailment Chart */}
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.1
          }}
          onClick={() => onNavigate('curtailment-detail')}
          className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors">

          <h3 className="text-lg font-semibold text-slate-100 mb-6">
            Curtailment Rate (%)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockPerformanceData}>
                <defs>
                  <linearGradient
                    id="colorCurtailment"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1">

                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#334155"
                  vertical={false} />

                <XAxis
                  dataKey="month"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <YAxis
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f1f5f9'
                  }} />

                <Area
                  type="monotone"
                  dataKey="curtailment"
                  stroke="#f59e0b"
                  fillOpacity={1}
                  fill="url(#colorCurtailment)"
                  name="Curtailment %" />

                <Line
                  type="monotone"
                  dataKey="curtailment"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  dot={true} />

              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Detailed Table */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-lg font-semibold text-slate-100">
            Monthly Breakdown
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-slate-400 uppercase bg-slate-900/50">
              <tr>
                <th className="px-6 py-3">Month</th>
                <th className="px-6 py-3">Revenue (ZAR)</th>
                <th className="px-6 py-3">Curtailment</th>
                <th className="px-6 py-3">Forecast Accuracy</th>
                <th className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {mockPerformanceData.map((row, i) =>
              <tr key={i} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-200">
                    {row.month}
                  </td>
                  <td className="px-6 py-4 text-emerald-400">
                    R{row.revenue}M
                  </td>
                  <td className="px-6 py-4 text-amber-400">
                    {row.curtailment}%
                  </td>
                  <td className="px-6 py-4 text-cyan-400">{row.accuracy}%</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      On Track
                    </span>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>);

}