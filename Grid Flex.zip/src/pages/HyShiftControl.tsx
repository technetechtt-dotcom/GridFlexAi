import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Droplet,
  Zap,
  Wind,
  Sun,
  Activity,
  ArrowRight,
  Settings,
  AlertTriangle,
  CheckCircle2,
  TrendingDown } from
'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { Page } from '../components/Sidebar';
import { KPICard } from '../components/KPICard';
import { StatusBadge } from '../components/StatusBadge';
import { PromptInput } from '../components/PromptInput';
import { cn } from '../lib/utils';
import { usePilotStore } from '../store/pilotStore';
interface HyShiftControlProps {
  onNavigate: (page: Page) => void;
}
const mockFlowData = [
{
  time: '06:00',
  solar: 0,
  wind: 150,
  grid: 50,
  electrolyzer: 20
},
{
  time: '08:00',
  solar: 100,
  wind: 120,
  grid: 20,
  electrolyzer: 80
},
{
  time: '10:00',
  solar: 300,
  wind: 100,
  grid: 0,
  electrolyzer: 250
},
{
  time: '12:00',
  solar: 450,
  wind: 80,
  grid: -50,
  electrolyzer: 380
},
{
  time: '14:00',
  solar: 400,
  wind: 90,
  grid: -20,
  electrolyzer: 350
},
{
  time: '16:00',
  solar: 250,
  wind: 110,
  grid: 0,
  electrolyzer: 200
},
{
  time: '18:00',
  solar: 50,
  wind: 140,
  grid: 80,
  electrolyzer: 50
}];

export function HyShiftControl({ onNavigate }: HyShiftControlProps) {
  const { submitPrompt } = usePilotStore();
  const [mode, setMode] = useState<'excess' | 'arbitrage' | 'ancillary'>(
    'excess'
  );
  const [rampRate, setRampRate] = useState(65);
  const chartData = useMemo(() => {
    const scale = rampRate / 65;
    return mockFlowData.map((d) => ({
      ...d,
      electrolyzer: Math.round(d.electrolyzer * scale),
      grid: Math.round(d.grid - d.electrolyzer * (scale - 1))
    }));
  }, [rampRate]);
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 flex items-center">
            <Droplet className="w-6 h-6 mr-3 text-cyan-400" />
            HyShift Control Center
          </h2>
          <p className="text-slate-400">
            Green Hydrogen Electrolyzer Optimization & Dispatch
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-700 flex items-center space-x-3">
            <span className="text-sm text-slate-400">System Status:</span>
            <StatusBadge status="active" label="Production Mode" />
          </div>
          <button className="flex items-center px-3 py-2 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Emergency Stop
          </button>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Current LCOH"
          value="R45.20"
          unit="/kg"
          trend="down"
          trendValue="R2.10"
          icon={TrendingDown}
          accentColor="emerald"
          delay={0.1} />

        <KPICard
          title="H2 Production Rate"
          value="420"
          unit="kg/h"
          trend="up"
          trendValue="15%"
          icon={Droplet}
          accentColor="cyan"
          delay={0.2} />

        <KPICard
          title="System Efficiency"
          value="52.4"
          unit="kWh/kg"
          trend="neutral"
          trendValue="0.1"
          icon={Zap}
          accentColor="purple"
          delay={0.3} />

        <KPICard
          title="Water Usage"
          value="3,850"
          unit="L/h"
          trend="up"
          trendValue="120L"
          icon={Activity}
          accentColor="amber"
          delay={0.4} />

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Control Panel & Stats */}
        <div className="space-y-6">
          {/* Control Panel */}
          <motion.div
            initial={{
              opacity: 0,
              x: -20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              delay: 0.2
            }}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6">

            <div className="flex items-center space-x-2 mb-6">
              <Settings className="w-5 h-5 text-emerald-500" />
              <h3 className="text-lg font-semibold text-slate-100">
                Grid-Responsive Control
              </h3>
            </div>

            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium text-slate-300 mb-3 block">
                  Optimization Strategy
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                  {
                    id: 'excess',
                    label: 'Follow Renewable Excess',
                    desc: 'Maximize use of curtailed solar/wind'
                  },
                  {
                    id: 'arbitrage',
                    label: 'Price Arbitrage',
                    desc: 'Produce when grid prices are lowest'
                  },
                  {
                    id: 'ancillary',
                    label: 'Ancillary Services',
                    desc: 'Provide frequency support to grid'
                  }].
                  map((option) =>
                  <button
                    key={option.id}
                    onClick={() => setMode(option.id as any)}
                    className={cn(
                      'flex flex-col items-start p-3 rounded-lg border transition-all text-left',
                      mode === option.id ?
                      'bg-emerald-500/10 border-emerald-500/50 text-emerald-400' :
                      'bg-slate-900/50 border-slate-700 text-slate-400 hover:border-slate-600'
                    )}>

                      <span className="font-medium text-sm">
                        {option.label}
                      </span>
                      <span className="text-xs opacity-70">{option.desc}</span>
                    </button>
                  )}
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-300">
                    Dynamic Load Setpoint
                  </label>
                  <span className="text-sm text-emerald-400 font-mono">
                    {rampRate}% ({Math.round(rampRate * 5)} MW)
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  step="1"
                  value={rampRate}
                  onChange={(e) => setRampRate(Number(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500" />

                <div className="flex justify-between mt-1 text-xs text-slate-500">
                  <span>Min (10%)</span>
                  <span>Max (100%)</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Daily Stats */}
          <motion.div
            initial={{
              opacity: 0,
              x: -20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              delay: 0.3
            }}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6">

            <h3 className="text-lg font-semibold text-slate-100 mb-4">
              Daily Performance
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                <span className="text-slate-400 text-sm">
                  H2 Produced Today
                </span>
                <span className="text-slate-200 font-bold">3,450 kg</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                <span className="text-slate-400 text-sm">CO₂ Avoided</span>
                <span className="text-emerald-400 font-bold">28.5 tons</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                <span className="text-slate-400 text-sm">
                  Curtailed Energy Captured
                </span>
                <span className="text-amber-400 font-bold">145 MWh</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right Column: Charts & AI */}
        <div className="lg:col-span-2 space-y-6">
          {/* Power Flow Chart */}
          <motion.div
            initial={{
              opacity: 0,
              y: 20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            transition={{
              delay: 0.4
            }}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6">

            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-slate-100">
                Real-time Power Flow Dispatch
              </h3>
              <div className="flex space-x-4 text-xs">
                <span className="flex items-center text-slate-400">
                  <Sun className="w-3 h-3 mr-1 text-amber-500" /> Solar
                </span>
                <span className="flex items-center text-slate-400">
                  <Wind className="w-3 h-3 mr-1 text-cyan-500" /> Wind
                </span>
                <span className="flex items-center text-slate-400">
                  <Droplet className="w-3 h-3 mr-1 text-purple-500" />{' '}
                  Electrolyzer
                </span>
              </div>
            </div>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorWind" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorH2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#334155"
                    vertical={false} />

                  <XAxis
                    dataKey="time"
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false} />

                  <YAxis
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `${val} MW`} />

                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      color: '#f1f5f9'
                    }} />

                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="solar"
                    stackId="1"
                    stroke="#f59e0b"
                    fill="url(#colorSolar)"
                    name="Solar Input" />

                  <Area
                    type="monotone"
                    dataKey="wind"
                    stackId="1"
                    stroke="#06b6d4"
                    fill="url(#colorWind)"
                    name="Wind Input" />

                  <Area
                    type="monotone"
                    dataKey="electrolyzer"
                    stackId="2"
                    stroke="#a855f7"
                    fill="url(#colorH2)"
                    name="H2 Load" />

                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* AI Prompt */}
          <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800">
            <PromptInput
              onSubmit={(val) => submitPrompt(val, 'hyshift')}
              placeholder="Ask HyShift AI (e.g., 'Optimize ramp rate for upcoming wind gust')"
              templates={[
              {
                label: 'Optimize Efficiency',
                prompt:
                'Adjust setpoints to maximize kWh/kg efficiency given current temp'
              },
              {
                label: 'Forecast H2',
                prompt:
                'Predict H2 production for next 24h based on weather forecast'
              },
              {
                label: 'Maintenance Check',
                prompt:
                'Analyze stack voltage deviation for potential degradation'
              }]
              } />

          </div>
        </div>
      </div>
    </div>);

}