import React from 'react';
import {
  Zap,
  Battery,
  DollarSign,
  Target,
  AlertTriangle,
  CheckCircle2,
  Wifi,
  Droplet } from
'lucide-react';
import { motion } from 'framer-motion';
import { KPICard } from '../components/KPICard';
import { HeatmapGrid } from '../components/HeatmapGrid';
import { StatusBadge } from '../components/StatusBadge';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer } from
'recharts';
import { Page } from '../components/Sidebar';
import { useRealTime } from '../context/RealTimeContext';
const mockHeatmapData = [
{
  node: 'Upington',
  values: [45, 60, 85, 90, 65, 40]
},
{
  node: 'De Aar',
  values: [30, 45, 55, 60, 45, 30]
},
{
  node: 'Cookhouse',
  values: [20, 25, 30, 45, 35, 25]
},
{
  node: 'Jeffreys Bay',
  values: [60, 75, 80, 70, 60, 50]
}];

const mockTimeLabels = ['06:00', '10:00', '14:00', '18:00', '22:00', '02:00'];
const mockChartData = [
{
  time: '00:00',
  actual: 400,
  forecast: 420
},
{
  time: '04:00',
  actual: 300,
  forecast: 310
},
{
  time: '08:00',
  actual: 600,
  forecast: 580
},
{
  time: '12:00',
  actual: 850,
  forecast: 890
},
{
  time: '16:00',
  actual: 700,
  forecast: 720
},
{
  time: '20:00',
  actual: 500,
  forecast: 480
},
{
  time: '23:59',
  actual: 450,
  forecast: 440
}];

interface DashboardProps {
  onNavigate: (page: Page) => void;
}
export function Dashboard({ onNavigate }: DashboardProps) {
  const { metrics, isConnected } = useRealTime();
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-100">System Overview</h2>
          <p className="text-slate-400">
            Real-time grid status and AI insights
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-full border ${isConnected ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>

            <Wifi className={`w-3 h-3 ${isConnected ? 'animate-pulse' : ''}`} />
            <span className="text-xs font-medium">
              {isConnected ? 'Live Stream' : 'Offline'}
            </span>
          </div>
          <span className="text-sm text-slate-500">
            {metrics.lastUpdated.toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div
          onClick={() => onNavigate('total-generation')}
          className="cursor-pointer">

          <KPICard
            title="Total Generation"
            value={Math.round(metrics.totalGeneration).toString()}
            unit="MW"
            trend="up"
            trendValue="12%"
            icon={Zap}
            accentColor="emerald"
            delay={0.1} />

        </div>
        <div
          onClick={() => onNavigate('curtailment-detail')}
          className="cursor-pointer">

          <KPICard
            title="Curtailment Rate"
            value="4.2"
            unit="%"
            trend="down"
            trendValue="0.8%"
            icon={AlertTriangle}
            accentColor="amber"
            delay={0.2} />

        </div>
        <div
          onClick={() => onNavigate('revenue-detail')}
          className="cursor-pointer">

          <KPICard
            title="Revenue Today"
            value="R2.4M"
            trend="up"
            trendValue="R150k"
            icon={DollarSign}
            accentColor="cyan"
            delay={0.3} />

        </div>
        <div
          onClick={() => onNavigate('forecast-accuracy')}
          className="cursor-pointer">

          <KPICard
            title="Forecast Accuracy"
            value="94.7"
            unit="%"
            trend="neutral"
            trendValue="0.1%"
            icon={Target}
            accentColor="purple"
            delay={0.4} />

        </div>
        <div onClick={() => onNavigate('hyshift')} className="cursor-pointer">
          <KPICard
            title="H₂ Production Today"
            value="1,240"
            unit="kg"
            trend="up"
            trendValue="18%"
            icon={Droplet}
            accentColor="purple"
            delay={0.5} />

        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Heatmap & Charts */}
        <div className="lg:col-span-2 space-y-6">
          <div
            onClick={() => onNavigate('congestion')}
            className="cursor-pointer">

            <HeatmapGrid
              title="Congestion Forecast (Next 24h)"
              data={mockHeatmapData}
              timeLabels={mockTimeLabels} />

          </div>

          <motion.div
            initial={{
              opacity: 0,
              y: 20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            transition={{
              delay: 0.5
            }}
            onClick={() => onNavigate('generation-vs-forecast')}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors">

            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-slate-100">
                Generation vs Forecast
              </h3>
              <select
                className="bg-slate-900 border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-1"
                onClick={(e) => e.stopPropagation()}>

                <option>All Nodes</option>
                <option>Upington</option>
                <option>De Aar</option>
              </select>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockChartData}>
                  <defs>
                    <linearGradient
                      id="colorActual"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1">

                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient
                      id="colorForecast"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1">

                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#334155"
                    vertical={false} />

                  <XAxis
                    dataKey="time"
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false} />

                  <YAxis
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value} MW`} />

                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      color: '#f1f5f9'
                    }}
                    itemStyle={{
                      color: '#f1f5f9'
                    }} />

                  <Area
                    type="monotone"
                    dataKey="actual"
                    stroke="#10b981"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorActual)"
                    name="Actual Generation" />

                  <Area
                    type="monotone"
                    dataKey="forecast"
                    stroke="#06b6d4"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    fillOpacity={1}
                    fill="url(#colorForecast)"
                    name="AI Forecast" />

                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Right Column: Recommendations & Status */}
        <div className="space-y-6">
          {/* Dispatch Status */}
          <motion.div
            initial={{
              opacity: 0,
              x: 20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              delay: 0.6
            }}
            onClick={() => onNavigate('dispatch-status')}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors">

            <h3 className="text-lg font-semibold text-slate-100 mb-4">
              Dispatch Status
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">Battery SOC (Total)</span>
                  <span className="text-emerald-400 font-medium">78%</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-emerald-500 h-2 rounded-full"
                    style={{
                      width: '78%'
                    }}>
                  </div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">Grid Capacity Usage</span>
                  <span className="text-amber-400 font-medium">82%</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-amber-500 h-2 rounded-full"
                    style={{
                      width: '82%'
                    }}>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-700">
                <h4 className="text-sm font-medium text-slate-300 mb-3">
                  Live Telemetry
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center text-slate-400">
                      <Zap className="w-3 h-3 mr-2" /> Frequency
                    </span>
                    <span className="font-mono text-emerald-400">
                      {metrics.frequency.toFixed(2)} Hz
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center text-slate-400">
                      <Zap className="w-3 h-3 mr-2" /> Voltage
                    </span>
                    <span className="font-mono text-emerald-400">
                      {metrics.voltage.toFixed(1)} kV
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center text-slate-400">
                      <Battery className="w-3 h-3 mr-2" /> Demand
                    </span>
                    <span className="font-mono text-amber-400">
                      {Math.round(metrics.demand)} MW
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* AI Recommendations */}
          <motion.div
            initial={{
              opacity: 0,
              x: 20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              delay: 0.7
            }}
            onClick={() => onNavigate('ai-insights')}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors">

            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-100">
                AI Insights
              </h3>
              <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-1 rounded border border-emerald-500/20">
                4 New
              </span>
            </div>
            <div className="space-y-3">
              {[
              {
                text: 'High congestion risk at Upington (14:00-16:00). Suggest curtailing 15MW.',
                priority: 'high'
              },
              {
                text: 'Battery charge opportunity at De Aar (10:00-12:00) due to excess solar.',
                priority: 'medium'
              },
              {
                text: 'HyShift: Route 25MW excess to electrolyzer at Upington (14:00). Produces 180 kg H₂, avoids curtailment.',
                priority: 'medium'
              },
              {
                text: 'Wind forecast updated: +12% output expected at Cookhouse tonight.',
                priority: 'low'
              }].
              map((rec, i) =>
              <div
                key={i}
                className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50 hover:border-slate-600 transition-colors">

                  <div className="flex items-start space-x-3">
                    {rec.priority === 'high' ?
                  <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" /> :

                  <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                  }
                    <p className="text-sm text-slate-300 leading-snug">
                      {rec.text}
                    </p>
                  </div>
                </div>
              )}
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onNavigate('all-recommendations');
              }}
              className="w-full mt-4 py-2 text-sm text-emerald-400 hover:text-emerald-300 font-medium border border-emerald-500/20 hover:bg-emerald-500/10 rounded-lg transition-all">

              View All Recommendations
            </button>
          </motion.div>
        </div>
      </div>
    </div>);

}