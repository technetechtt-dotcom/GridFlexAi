import React from 'react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { Page } from '../components/Sidebar';
interface CurtailmentDetailProps {
  onNavigate: (page: Page) => void;
}
const mockCurtailmentData = [
{
  reason: 'Grid Congestion',
  value: 45,
  fill: '#ef4444'
},
{
  reason: 'Over-generation',
  value: 30,
  fill: '#f59e0b'
},
{
  reason: 'Maintenance',
  value: 15,
  fill: '#3b82f6'
},
{
  reason: 'Other',
  value: 10,
  fill: '#64748b'
}];

const mockNodeCurtailment = [
{
  node: 'Upington',
  curtailed: 15,
  total: 300
},
{
  node: 'De Aar',
  curtailed: 8,
  total: 250
},
{
  node: 'Cookhouse',
  curtailed: 2,
  total: 140
},
{
  node: 'Jeffreys Bay',
  curtailed: 0,
  total: 138
}];

export function CurtailmentDetail({ onNavigate }: CurtailmentDetailProps) {
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex items-center space-x-4 mb-6">
        <button
          onClick={() => onNavigate('dashboard')}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors">

          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Curtailment Analysis
          </h2>
          <p className="text-slate-400">Detailed breakdown of energy losses</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          className="bg-slate-800 border border-slate-700 rounded-xl p-6">

          <h3 className="text-lg font-semibold text-slate-100 mb-6">
            Curtailment Reasons
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockCurtailmentData} layout="vertical">
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#334155"
                  horizontal={false} />

                <XAxis
                  type="number"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  unit="%" />

                <YAxis
                  dataKey="reason"
                  type="category"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  width={100} />

                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f1f5f9'
                  }}
                  itemStyle={{
                    color: '#f1f5f9'
                  }} />

                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.1
          }}
          className="bg-slate-800 border border-slate-700 rounded-xl p-6">

          <h3 className="text-lg font-semibold text-slate-100 mb-6">
            Curtailment by Node (MW)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockNodeCurtailment}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#334155"
                  vertical={false} />

                <XAxis
                  dataKey="node"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <YAxis
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f1f5f9'
                  }}
                  itemStyle={{
                    color: '#f1f5f9'
                  }} />

                <Legend />
                <Bar
                  dataKey="curtailed"
                  fill="#ef4444"
                  name="Curtailed MW"
                  radius={[4, 4, 0, 0]} />

                <Bar
                  dataKey="total"
                  fill="#334155"
                  name="Total Capacity MW"
                  radius={[4, 4, 0, 0]} />

              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
        <div className="flex items-start space-x-4">
          <div className="bg-amber-500/10 p-3 rounded-lg">
            <AlertTriangle className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-100 mb-2">
              Impact Analysis
            </h3>
            <p className="text-slate-400 mb-4">
              Current curtailment rate of{' '}
              <span className="text-amber-400 font-bold">4.2%</span> is slightly
              above the target of 3.0%. The primary driver is grid congestion at
              the Upington node during peak solar hours (12:00 - 14:00).
            </p>
            <div className="flex space-x-4">
              <div>
                <span className="text-xs text-slate-500 uppercase tracking-wider">
                  Lost Revenue
                </span>
                <p className="text-xl font-bold text-slate-200">R125,000</p>
              </div>
              <div>
                <span className="text-xs text-slate-500 uppercase tracking-wider">
                  Energy Lost
                </span>
                <p className="text-xl font-bold text-slate-200">145 MWh</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

}