import React from 'react';
import {
  ArrowLeft,
  Target,
  TrendingUp,
  AlertTriangle,
  Download,
  RefreshCw } from
'lucide-react';
import { motion } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { Page } from '../components/Sidebar';
import { StatusBadge } from '../components/StatusBadge';
interface GenerationVsForecastProps {
  onNavigate: (page: Page) => void;
}
const mockChartData = [
{
  time: '00:00',
  actual: 400,
  forecast: 420
},
{
  time: '04:00',
  actual: 300,
  forecast: 310
},
{
  time: '08:00',
  actual: 600,
  forecast: 580
},
{
  time: '12:00',
  actual: 850,
  forecast: 890
},
{
  time: '16:00',
  actual: 700,
  forecast: 720
},
{
  time: '20:00',
  actual: 500,
  forecast: 480
},
{
  time: '23:59',
  actual: 450,
  forecast: 440
}];

const nodeBreakdown = [
{
  node: 'Upington',
  actual: 280,
  forecast: 290,
  error: 10,
  pct: 3.4,
  status: 'optimal'
},
{
  node: 'De Aar',
  actual: 220,
  forecast: 215,
  error: -5,
  pct: 2.3,
  status: 'optimal'
},
{
  node: 'Cookhouse',
  actual: 120,
  forecast: 135,
  error: 15,
  pct: 11.1,
  status: 'warning'
},
{
  node: 'Jeffreys Bay',
  actual: 110,
  forecast: 108,
  error: -2,
  pct: 1.8,
  status: 'optimal'
},
{
  node: 'Komani',
  actual: 40,
  forecast: 38,
  error: -2,
  pct: 5.0,
  status: 'active'
}];

export function GenerationVsForecast({
  onNavigate
}: GenerationVsForecastProps) {
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => onNavigate('dashboard')}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors">

            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-100">
              Generation vs Forecast
            </h2>
            <p className="text-slate-400">
              Real-time performance against AI predictions
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
            <Download className="w-4 h-4 mr-2" />
            Export Comparison
          </button>
          <button className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retrain Model
          </button>
          <button
            onClick={() => onNavigate('forecast-accuracy')}
            className="flex items-center px-3 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition-colors font-medium shadow-lg shadow-emerald-500/20">

            <Target className="w-4 h-4 mr-2" />
            View Forecast Accuracy
          </button>
        </div>
      </div>

      {/* Accuracy Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
        {
          label: 'Overall MAPE',
          value: '4.7%',
          trend: 'down',
          color: 'text-emerald-400'
        },
        {
          label: 'Solar Accuracy',
          value: '96.2%',
          trend: 'up',
          color: 'text-emerald-400'
        },
        {
          label: 'Wind Accuracy',
          value: '91.8%',
          trend: 'down',
          color: 'text-amber-400'
        },
        {
          label: 'Peak Hour Error',
          value: '2.1%',
          trend: 'down',
          color: 'text-emerald-400'
        }].
        map((stat, i) =>
        <motion.div
          key={i}
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: i * 0.05
          }}
          className="bg-slate-800 border border-slate-700 rounded-xl p-5">

            <p className="text-sm text-slate-400 font-medium mb-1">
              {stat.label}
            </p>
            <div className="flex items-end justify-between">
              <h3 className={`text-2xl font-bold ${stat.color}`}>
                {stat.value}
              </h3>
              <TrendingUp className="w-4 h-4 text-slate-500" />
            </div>
          </motion.div>
        )}
      </div>

      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        transition={{
          delay: 0.2
        }}
        className="bg-slate-800 border border-slate-700 rounded-xl p-6">

        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-slate-100">
            Detailed Comparison (24h)
          </h3>
          <select className="bg-slate-900 border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-1">
            <option>All Nodes</option>
            <option>Upington</option>
            <option>De Aar</option>
          </select>
        </div>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockChartData}>
              <defs>
                <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
                vertical={false} />

              <XAxis
                dataKey="time"
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false} />

              <YAxis
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value} MW`} />

              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  color: '#f1f5f9'
                }}
                itemStyle={{
                  color: '#f1f5f9'
                }} />

              <Legend />
              <Area
                type="monotone"
                dataKey="actual"
                stroke="#10b981"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorActual)"
                name="Actual Generation" />

              <Area
                type="monotone"
                dataKey="forecast"
                stroke="#06b6d4"
                strokeWidth={2}
                strokeDasharray="5 5"
                fillOpacity={1}
                fill="url(#colorForecast)"
                name="AI Forecast" />

            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Node Breakdown Table */}
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.3
          }}
          className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">

          <div className="p-4 border-b border-slate-700 bg-slate-800/50">
            <h3 className="text-lg font-semibold text-slate-100">
              Per-Node Performance Breakdown
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-slate-400 uppercase bg-slate-900/50">
                <tr>
                  <th className="px-6 py-3">Node</th>
                  <th className="px-6 py-3">Actual (MW)</th>
                  <th className="px-6 py-3">Forecast (MW)</th>
                  <th className="px-6 py-3">Error (MW)</th>
                  <th className="px-6 py-3">Error %</th>
                  <th className="px-6 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {nodeBreakdown.map((row, i) =>
                <tr
                  key={i}
                  className="hover:bg-slate-700/30 transition-colors">

                    <td className="px-6 py-4 font-medium text-slate-200">
                      {row.node}
                    </td>
                    <td className="px-6 py-4 text-slate-300">{row.actual}</td>
                    <td className="px-6 py-4 text-slate-400">{row.forecast}</td>
                    <td className="px-6 py-4 text-slate-400">
                      {row.error > 0 ? '+' : ''}
                      {row.error}
                    </td>
                    <td className="px-6 py-4">
                      <span
                      className={`font-mono font-medium ${row.pct > 10 ? 'text-red-400' : row.pct > 5 ? 'text-amber-400' : 'text-emerald-400'}`}>

                        {row.pct}%
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={row.status as any} />
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Deviation Highlights */}
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.4
          }}
          className="space-y-4">

          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-100 mb-4 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-amber-500" />
              Largest Deviations
            </h3>
            <div className="space-y-4">
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium text-slate-200">
                    Cookhouse Wind
                  </span>
                  <span className="text-xs font-bold text-red-400 bg-red-500/10 px-2 py-0.5 rounded">
                    +11.1%
                  </span>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Over-forecast due to unexpected wind speed drop at 14:00
                  (actual 6.2 m/s vs forecast 8.1 m/s).
                </p>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium text-slate-200">
                    Komani Solar
                  </span>
                  <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                    +5.0%
                  </span>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Cloud cover transient passing faster than predicted by weather
                  model.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>);

}