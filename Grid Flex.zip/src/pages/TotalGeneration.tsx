import React from 'react';
import { ArrowLeft, Zap, Sun, Wind } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { StatusBadge } from '../components/StatusBadge';
import { Page } from '../components/Sidebar';
interface TotalGenerationProps {
  onNavigate: (page: Page) => void;
}
const mockGenerationData = [
{
  time: '00:00',
  solar: 0,
  wind: 320,
  total: 320
},
{
  time: '04:00',
  solar: 0,
  wind: 350,
  total: 350
},
{
  time: '08:00',
  solar: 250,
  wind: 280,
  total: 530
},
{
  time: '12:00',
  solar: 850,
  wind: 150,
  total: 1000
},
{
  time: '16:00',
  solar: 600,
  wind: 220,
  total: 820
},
{
  time: '20:00',
  solar: 50,
  wind: 300,
  total: 350
},
{
  time: '23:59',
  solar: 0,
  wind: 340,
  total: 340
}];

export function TotalGeneration({ onNavigate }: TotalGenerationProps) {
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex items-center space-x-4 mb-6">
        <button
          onClick={() => onNavigate('dashboard')}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors">

          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Total Generation
          </h2>
          <p className="text-slate-400">
            Detailed breakdown of generation sources
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Current Output</span>
            <Zap className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">847 MW</div>
          <div className="text-sm text-emerald-400 mt-1">+12% vs yesterday</div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Solar Contribution</span>
            <Sun className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">540 MW</div>
          <div className="text-sm text-slate-500 mt-1">64% of total</div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Wind Contribution</span>
            <Wind className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">307 MW</div>
          <div className="text-sm text-slate-500 mt-1">36% of total</div>
        </div>
      </div>

      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        className="bg-slate-800 border border-slate-700 rounded-xl p-6">

        <h3 className="text-lg font-semibold text-slate-100 mb-6">
          Generation Mix (24h)
        </h3>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockGenerationData}>
              <defs>
                <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorWind" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
                vertical={false} />

              <XAxis
                dataKey="time"
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false} />

              <YAxis
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false} />

              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  color: '#f1f5f9'
                }}
                itemStyle={{
                  color: '#f1f5f9'
                }} />

              <Legend />
              <Area
                type="monotone"
                dataKey="solar"
                stackId="1"
                stroke="#f59e0b"
                fill="url(#colorSolar)"
                name="Solar PV" />

              <Area
                type="monotone"
                dataKey="wind"
                stackId="1"
                stroke="#06b6d4"
                fill="url(#colorWind)"
                name="Wind" />

            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-lg font-semibold text-slate-100">
            Asset Performance
          </h3>
        </div>
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-400 uppercase bg-slate-900/50">
            <tr>
              <th className="px-6 py-3">Asset Name</th>
              <th className="px-6 py-3">Type</th>
              <th className="px-6 py-3">Capacity</th>
              <th className="px-6 py-3">Current Output</th>
              <th className="px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {[
            {
              name: 'Upington Solar',
              type: 'Solar PV',
              cap: '300 MW',
              curr: '280 MW',
              status: 'optimal'
            },
            {
              name: 'De Aar Solar',
              type: 'Solar PV',
              cap: '250 MW',
              curr: '220 MW',
              status: 'optimal'
            },
            {
              name: 'Cookhouse Wind',
              type: 'Wind',
              cap: '140 MW',
              curr: '120 MW',
              status: 'active'
            },
            {
              name: 'Jeffreys Bay Wind',
              type: 'Wind',
              cap: '138 MW',
              curr: '110 MW',
              status: 'active'
            },
            {
              name: 'Komani Solar',
              type: 'Solar PV',
              cap: '50 MW',
              curr: '40 MW',
              status: 'warning'
            }].
            map((row, i) =>
            <tr key={i} className="hover:bg-slate-700/30 transition-colors">
                <td className="px-6 py-4 font-medium text-slate-200">
                  {row.name}
                </td>
                <td className="px-6 py-4 text-slate-400">{row.type}</td>
                <td className="px-6 py-4 text-slate-400">{row.cap}</td>
                <td className="px-6 py-4 text-emerald-400">{row.curr}</td>
                <td className="px-6 py-4">
                  <StatusBadge status={row.status as any} />
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>);

}