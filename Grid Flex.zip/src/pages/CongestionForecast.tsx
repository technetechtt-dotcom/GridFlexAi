import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Calendar,
  Filter,
  Download,
  ArrowRight,
  Activity,
  Droplet } from
'lucide-react';
import { HeatmapGrid } from '../components/HeatmapGrid';
import { PromptInput } from '../components/PromptInput';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer } from
'recharts';
import { Page } from '../components/Sidebar';
import { usePilotStore } from '../store/pilotStore';
interface CongestionForecastProps {
  onNavigate: (page: Page) => void;
}
const mockForecastData = [
{
  node: 'Upington',
  values: [45, 60, 85, 90, 65, 40, 30, 25, 20, 15, 10, 5]
},
{
  node: 'De Aar',
  values: [30, 45, 55, 60, 45, 30, 25, 20, 15, 10, 5, 5]
},
{
  node: 'Prieska',
  values: [25, 40, 65, 75, 50, 35, 25, 20, 15, 10, 5, 5]
},
{
  node: 'Kathu',
  values: [20, 35, 50, 55, 40, 25, 20, 15, 10, 5, 5, 5]
},
{
  node: 'Boegoebaai',
  values: [15, 25, 35, 40, 30, 20, 15, 10, 5, 5, 5, 5]
},
{
  node: 'Cookhouse',
  values: [20, 25, 30, 45, 35, 25, 40, 55, 60, 50, 40, 30]
},
{
  node: 'Jeffreys Bay',
  values: [60, 75, 80, 70, 60, 50, 45, 40, 35, 30, 25, 20]
}];

const mockTimeLabels = [
'06:00',
'12:00',
'18:00',
'00:00',
'06:00',
'12:00',
'18:00',
'00:00',
'06:00',
'12:00',
'18:00',
'00:00'];

const mockChartData = Array.from(
  {
    length: 24
  },
  (_, i) => ({
    time: `${i}:00`,
    upington: 50 + Math.sin(i / 3) * 40 + Math.random() * 10,
    deAar: 40 + Math.sin(i / 4) * 30 + Math.random() * 10,
    limit: 90
  })
);
export function CongestionForecast({ onNavigate }: CongestionForecastProps) {
  const { submitPrompt } = usePilotStore();
  const [filterNode, setFilterNode] = useState('All');
  const [showHyShift, setShowHyShift] = useState(false);
  const displayData = useMemo(() => {
    if (!showHyShift) return mockForecastData;
    return mockForecastData.map((row) => ({
      ...row,
      values: row.values.map((v) => Math.max(0, Math.round(v * 0.78)))
    }));
  }, [showHyShift]);
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Congestion Forecasting
          </h2>
          <p className="text-slate-400">
            72-hour grid congestion prediction across all nodes
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowHyShift(!showHyShift)}
            className={`flex items-center px-3 py-2 rounded-lg transition-all border ${showHyShift ? 'bg-purple-500/20 border-purple-500/50 text-purple-300' : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'}`}>

            <Droplet
              className={`w-4 h-4 mr-2 ${showHyShift ? 'text-purple-400' : ''}`} />

            Show with HyShift
          </button>
          <button
            onClick={() => onNavigate('generation-vs-forecast')}
            className="flex items-center px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 hover:bg-emerald-500/20 transition-colors">

            <Activity className="w-4 h-4 mr-2" />
            Compare vs Actual
          </button>
          <button className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
            <Calendar className="w-4 h-4 mr-2" />
            Next 72 Hours
          </button>
          <button className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {showHyShift &&
      <motion.div
        initial={{
          opacity: 0,
          height: 0
        }}
        animate={{
          opacity: 1,
          height: 'auto'
        }}
        className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3 flex items-center text-sm text-purple-200">

          <Droplet className="w-4 h-4 mr-2 text-purple-400" />
          HyShift flexible load absorbs excess generation, reducing congestion
          by ~22% across critical nodes.
        </motion.div>
      }

      {/* AI Prompt */}
      <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800">
        <PromptInput
          onSubmit={(val) => submitPrompt(val, 'congestion')}
          placeholder="Ask about congestion (e.g., 'Show me congestion risks for Upington tomorrow')"
          templates={[
          {
            label: 'Upington Forecast',
            prompt: 'Show congestion forecast for Upington next 48 hours'
          },
          {
            label: 'High Risk Nodes',
            prompt: 'Identify nodes with >80% congestion probability'
          },
          {
            label: 'Weather Impact',
            prompt: 'How will cloud cover affect De Aar congestion tomorrow?'
          }]
          } />

      </div>

      {/* Heatmap */}
      <HeatmapGrid
        title={`Network Congestion Heatmap (72h)${showHyShift ? ' - HyShift Optimized' : ''}`}
        data={displayData}
        timeLabels={mockTimeLabels} />


      {/* Detailed Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.2
          }}
          className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-xl p-6">

          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold text-slate-100">
              Congestion Trend Analysis
            </h3>
            <div className="flex space-x-2">
              <span className="flex items-center text-xs text-slate-400">
                <span className="w-3 h-3 bg-emerald-500 rounded-full mr-1"></span>{' '}
                Upington
              </span>
              <span className="flex items-center text-xs text-slate-400">
                <span className="w-3 h-3 bg-cyan-500 rounded-full mr-1"></span>{' '}
                De Aar
              </span>
              <span className="flex items-center text-xs text-slate-400">
                <span className="w-3 h-3 bg-red-500 rounded-full mr-1"></span>{' '}
                Limit
              </span>
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockChartData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#334155"
                  vertical={false} />

                <XAxis
                  dataKey="time"
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false} />

                <YAxis
                  stroke="#94a3b8"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  unit="%" />

                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f1f5f9'
                  }}
                  itemStyle={{
                    color: '#f1f5f9'
                  }} />

                <Line
                  type="monotone"
                  dataKey="upington"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={false} />

                <Line
                  type="monotone"
                  dataKey="deAar"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  dot={false} />

                <Line
                  type="monotone"
                  dataKey="limit"
                  stroke="#ef4444"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false} />

              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Risk Table */}
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: 0.3
          }}
          className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">

          <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-100">
              High Risk Nodes
            </h3>
            <button
              onClick={() => onNavigate('dispatch-status')}
              className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center transition-colors">

              View Dispatch <ArrowRight className="w-3 h-3 ml-1" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-slate-400 uppercase bg-slate-900/50">
                <tr>
                  <th className="px-4 py-3">Node</th>
                  <th className="px-4 py-3">Peak %</th>
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">Risk</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {[
                {
                  node: 'Upington',
                  peak: 92,
                  time: '14:00',
                  risk: 'Critical'
                },
                {
                  node: 'Jeffreys Bay',
                  peak: 80,
                  time: '15:30',
                  risk: 'High'
                },
                {
                  node: 'De Aar',
                  peak: 65,
                  time: '13:00',
                  risk: 'Medium'
                },
                {
                  node: 'Humansdorp',
                  peak: 70,
                  time: '16:00',
                  risk: 'Medium'
                },
                {
                  node: 'Cookhouse',
                  peak: 60,
                  time: '14:00',
                  risk: 'Low'
                }].
                map((row, i) =>
                <tr
                  key={i}
                  onClick={() => onNavigate('dispatch-status')}
                  className="hover:bg-slate-700/30 transition-colors cursor-pointer">

                    <td className="px-4 py-3 font-medium text-slate-200">
                      {row.node}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{row.peak}%</td>
                    <td className="px-4 py-3 text-slate-400">{row.time}</td>
                    <td className="px-4 py-3">
                      <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                        ${row.risk === 'Critical' ? 'bg-red-500/10 text-red-400' : row.risk === 'High' ? 'bg-amber-500/10 text-amber-400' : row.risk === 'Medium' ? 'bg-yellow-500/10 text-yellow-400' : 'bg-emerald-500/10 text-emerald-400'}`}>

                        {row.risk}
                      </span>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>);

}