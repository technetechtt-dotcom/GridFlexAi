import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Battery,
  Zap,
  ArrowRight,
  Check,
  AlertTriangle,
  Play,
  TrendingUp,
  Droplet } from
'lucide-react';
import { PromptInput } from '../components/PromptInput';
import { StatusBadge } from '../components/StatusBadge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area } from
'recharts';
import { Page } from '../components/Sidebar';
import { usePilotStore } from '../store/pilotStore';
interface DispatchOptimizationProps {
  onNavigate: (page: Page) => void;
}
const mockDispatchData = [
{
  time: '00:00',
  solar: 0,
  wind: 300,
  battery: -50,
  electrolyzer: 0,
  demand: 250
},
{
  time: '04:00',
  solar: 0,
  wind: 350,
  battery: -50,
  electrolyzer: 0,
  demand: 300
},
{
  time: '08:00',
  solar: 200,
  wind: 200,
  battery: 0,
  electrolyzer: 0,
  demand: 400
},
{
  time: '12:00',
  solar: 800,
  wind: 150,
  battery: 100,
  electrolyzer: 150,
  demand: 850
},
{
  time: '16:00',
  solar: 600,
  wind: 200,
  battery: 50,
  electrolyzer: 100,
  demand: 750
},
{
  time: '20:00',
  solar: 50,
  wind: 300,
  battery: -100,
  electrolyzer: 0,
  demand: 450
}];

const recommendations = [
{
  id: 1,
  type: 'curtailment',
  title: 'Curtail Upington Solar',
  description:
  'Reduce output by 15MW during 14:00-16:00 to avoid grid congestion.',
  impact: '+R12,500 revenue preserved',
  status: 'pending'
},
{
  id: 2,
  type: 'battery',
  title: 'Battery Charge Cycle',
  description:
  'Charge De Aar BESS at max rate (10MW) from 11:00-13:00 using excess solar.',
  impact: 'Optimize for evening peak',
  status: 'pending'
},
{
  id: 3,
  type: 'dispatch',
  title: 'Increase Wind Dispatch',
  description:
  'Ramp up Cookhouse wind farm to 95% capacity for evening peak demand.',
  impact: 'Meet contract obligation',
  status: 'approved'
},
{
  id: 4,
  type: 'hyshift',
  title: 'Route 25 MW to Electrolyzer',
  description:
  'Redirect excess solar at Upington (14:00-16:00) to electrolyzer instead of curtailing.',
  impact: 'Avoids curtailment + produces 180 kg H₂',
  status: 'pending'
}];

export function DispatchOptimization({
  onNavigate
}: DispatchOptimizationProps) {
  const { submitPrompt } = usePilotStore();
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Dispatch Optimization
          </h2>
          <p className="text-slate-400">
            Real-time control for generation and storage assets
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigate('dispatch-status')}
            className="flex items-center px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">

            <Battery className="w-4 h-4 mr-2" />
            View Asset Status
          </button>
          <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-700 flex items-center space-x-3">
            <span className="text-sm text-slate-400">Auto-Dispatch Mode:</span>
            <StatusBadge status="active" label="Enabled" />
          </div>
        </div>
      </div>

      {/* AI Prompt */}
      <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800">
        <PromptInput
          onSubmit={(val) => {
            submitPrompt(val, 'dispatch');
            // In a real app, we'd show a toast here
          }}
          placeholder="Ask for dispatch advice (e.g., 'Optimize dispatch for Upington considering battery SOC at 45%')"
          templates={[
          {
            label: 'Optimize Battery',
            prompt:
            'Suggest battery schedule for next 24h to maximize revenue'
          },
          {
            label: 'Curtailment Strategy',
            prompt: 'How to minimize curtailment at De Aar today?'
          }]
          } />

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Charts */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Dispatch Chart */}
          <motion.div
            initial={{
              opacity: 0,
              y: 20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6">

            <h3 className="text-lg font-semibold text-slate-100 mb-6">
              Generation & Dispatch Mix
            </h3>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={mockDispatchData}>
                  <defs>
                    <linearGradient
                      id="colorElectrolyzer"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1">

                      <stop offset="5%" stopColor="#a855f7" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#334155"
                    vertical={false} />

                  <XAxis
                    dataKey="time"
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false} />

                  <YAxis
                    stroke="#94a3b8"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false} />

                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      color: '#f1f5f9'
                    }}
                    itemStyle={{
                      color: '#f1f5f9'
                    }} />

                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="solar"
                    stackId="1"
                    fill="#10b981"
                    stroke="#10b981"
                    fillOpacity={0.6}
                    name="Solar PV" />

                  <Area
                    type="monotone"
                    dataKey="wind"
                    stackId="1"
                    fill="#06b6d4"
                    stroke="#06b6d4"
                    fillOpacity={0.6}
                    name="Wind" />

                  <Area
                    type="monotone"
                    dataKey="electrolyzer"
                    stackId="1"
                    fill="url(#colorElectrolyzer)"
                    stroke="#a855f7"
                    fillOpacity={0.6}
                    name="Electrolyzer Load" />

                  <Bar
                    dataKey="battery"
                    fill="#f59e0b"
                    name="Battery Flow (+Chg/-Dis)" />

                  <Line
                    type="monotone"
                    dataKey="demand"
                    stroke="#ef4444"
                    strokeWidth={2}
                    dot={false}
                    name="Grid Demand" />

                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Revenue Impact */}
          <motion.div
            initial={{
              opacity: 0,
              y: 20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            transition={{
              delay: 0.1
            }}
            onClick={() => onNavigate('revenue-detail')}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6 cursor-pointer hover:border-slate-600 transition-colors group">

            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-slate-100">
                Revenue Optimization
              </h3>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                <p className="text-sm text-slate-400 mb-1">Baseline Revenue</p>
                <p className="text-2xl font-bold text-slate-300">R2.1M</p>
              </div>
              <div className="bg-emerald-500/10 p-4 rounded-lg border border-emerald-500/20">
                <p className="text-sm text-emerald-400 mb-1">
                  Optimized Revenue
                </p>
                <p className="text-2xl font-bold text-emerald-400">R2.4M</p>
                <p className="text-xs text-emerald-500 mt-1">+14.2% uplift</p>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                <p className="text-sm text-slate-400 mb-1">Avoided Penalties</p>
                <p className="text-2xl font-bold text-slate-300">R45k</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right: Recommendations */}
        <div className="space-y-6">
          <motion.div
            initial={{
              opacity: 0,
              x: 20
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              delay: 0.2
            }}
            className="bg-slate-800 border border-slate-700 rounded-xl p-6 h-full">

            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-100">
                AI Recommendations
              </h3>
              <span className="text-xs text-slate-400">Updated 2m ago</span>
            </div>

            <div className="space-y-4">
              {recommendations.map((rec) =>
              <div
                key={rec.id}
                className="bg-slate-900 border border-slate-700 rounded-lg p-4 hover:border-slate-600 transition-all group">

                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center space-x-2">
                      {rec.type === 'curtailment' &&
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    }
                      {rec.type === 'battery' &&
                    <Battery className="w-4 h-4 text-emerald-500" />
                    }
                      {rec.type === 'dispatch' &&
                    <Zap className="w-4 h-4 text-cyan-500" />
                    }
                      {rec.type === 'hyshift' &&
                    <Droplet className="w-4 h-4 text-purple-500" />
                    }
                      <span className="font-medium text-slate-200 text-sm">
                        {rec.title}
                      </span>
                    </div>
                    {rec.status === 'approved' ?
                  <span className="text-xs text-emerald-500 flex items-center">
                        <Check className="w-3 h-3 mr-1" /> Approved
                      </span> :

                  <span className="text-xs text-slate-500">Pending</span>
                  }
                  </div>

                  <p className="text-sm text-slate-400 mb-3">
                    {rec.description}
                  </p>

                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-emerald-400">
                      {rec.impact}
                    </span>
                    {rec.status === 'pending' &&
                  <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-slate-200">
                          <span className="sr-only">Dismiss</span>
                          <ArrowRight className="w-4 h-4 rotate-180" />
                        </button>
                        <button className="px-3 py-1 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-medium rounded transition-colors">
                          Approve
                        </button>
                      </div>
                  }
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => onNavigate('all-recommendations')}
              className="w-full mt-6 flex items-center justify-center px-4 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition-colors font-medium">

              <Play className="w-4 h-4 mr-2" />
              View All Recommendations
            </button>
          </motion.div>
        </div>
      </div>
    </div>);

}