import React from 'react';
import { ArrowLeft, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend } from
'recharts';
import { Page } from '../components/Sidebar';
interface ForecastAccuracyProps {
  onNavigate: (page: Page) => void;
}
const mockAccuracyData = [
{
  day: 'Mon',
  accuracy: 92,
  target: 95
},
{
  day: 'Tue',
  accuracy: 94,
  target: 95
},
{
  day: 'Wed',
  accuracy: 96,
  target: 95
},
{
  day: 'Thu',
  accuracy: 95,
  target: 95
},
{
  day: 'Fri',
  accuracy: 93,
  target: 95
},
{
  day: 'Sat',
  accuracy: 97,
  target: 95
},
{
  day: 'Sun',
  accuracy: 98,
  target: 95
}];

export function ForecastAccuracy({ onNavigate }: ForecastAccuracyProps) {
  return (
    <div className="space-y-6 p-6 pb-20">
      <div className="flex items-center space-x-4 mb-6">
        <button
          onClick={() => onNavigate('dashboard')}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors">

          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-100">
            Forecast Accuracy
          </h2>
          <p className="text-slate-400">Model performance tracking</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Overall Accuracy</span>
            <Target className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-3xl font-bold text-slate-100">94.7%</div>
          <div className="text-sm text-slate-500 mt-1">Last 7 days</div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Solar MAE</span>
            <span className="text-xs text-slate-500">Mean Absolute Error</span>
          </div>
          <div className="text-3xl font-bold text-slate-100">3.2%</div>
          <div className="text-sm text-emerald-400 mt-1">Excellent</div>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">Wind MAE</span>
            <span className="text-xs text-slate-500">Mean Absolute Error</span>
          </div>
          <div className="text-3xl font-bold text-slate-100">5.8%</div>
          <div className="text-sm text-amber-400 mt-1">Within tolerance</div>
        </div>
      </div>

      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        className="bg-slate-800 border border-slate-700 rounded-xl p-6">

        <h3 className="text-lg font-semibold text-slate-100 mb-6">
          Accuracy Trend (7 Days)
        </h3>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockAccuracyData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
                vertical={false} />

              <XAxis
                dataKey="day"
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false} />

              <YAxis
                domain={[80, 100]}
                stroke="#94a3b8"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                unit="%" />

              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  color: '#f1f5f9'
                }}
                itemStyle={{
                  color: '#f1f5f9'
                }} />

              <Legend />
              <Line
                type="monotone"
                dataKey="accuracy"
                stroke="#a855f7"
                strokeWidth={3}
                dot={{
                  r: 4
                }}
                name="Model Accuracy" />

              <Line
                type="monotone"
                dataKey="target"
                stroke="#94a3b8"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                name="Target (95%)" />

            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>);

}