import React, { useState, createContext, useContext } from 'react';
import { auditLogger } from '../lib/auditLogger';
interface User {
  id: string;
  name: string;
  role: 'operator' | 'admin' | 'viewer';
  email: string;
}
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}
const AuthContext = createContext<AuthContextType | undefined>(undefined);
export function AuthProvider({ children }: {children: ReactNode;}) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const login = async (email: string) => {
    setIsLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    const mockUser: User = {
      id: 'u-123',
      name: 'John Doe',
      role: 'operator',
      email
    };
    setUser(mockUser);
    auditLogger.log('USER_LOGIN', mockUser.id, {
      email
    });
    setIsLoading(false);
  };
  const logout = () => {
    if (user) {
      auditLogger.log('USER_LOGOUT', user.id);
    }
    setUser(null);
  };
  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        isLoading
      }}>

      {children}
    </AuthContext.Provider>);

}
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}