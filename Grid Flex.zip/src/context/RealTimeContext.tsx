import React, { useEffect, useState, createContext, useContext } from 'react';
interface GridMetrics {
  frequency: number;
  voltage: number;
  totalGeneration: number;
  demand: number;
  lastUpdated: Date;
}
interface RealTimeContextType {
  metrics: GridMetrics;
  isConnected: boolean;
}
const RealTimeContext = createContext<RealTimeContextType | undefined>(
  undefined
);
export function RealTimeProvider({ children }: {children: ReactNode;}) {
  const [metrics, setMetrics] = useState<GridMetrics>({
    frequency: 50.0,
    voltage: 132.0,
    totalGeneration: 847,
    demand: 820,
    lastUpdated: new Date()
  });
  const [isConnected, setIsConnected] = useState(false);
  useEffect(() => {
    // Simulate WebSocket connection
    setIsConnected(true);
    const interval = setInterval(() => {
      setMetrics((prev) => ({
        frequency: 50.0 + (Math.random() - 0.5) * 0.1,
        voltage: 132.0 + (Math.random() - 0.5) * 2,
        totalGeneration: prev.totalGeneration + (Math.random() - 0.5) * 10,
        demand: prev.demand + (Math.random() - 0.5) * 15,
        lastUpdated: new Date()
      }));
    }, 2000); // Update every 2 seconds
    return () => {
      clearInterval(interval);
      setIsConnected(false);
    };
  }, []);
  return (
    <RealTimeContext.Provider
      value={{
        metrics,
        isConnected
      }}>

      {children}
    </RealTimeContext.Provider>);

}
export function useRealTime() {
  const context = useContext(RealTimeContext);
  if (context === undefined) {
    throw new Error('useRealTime must be used within a RealTimeProvider');
  }
  return context;
}