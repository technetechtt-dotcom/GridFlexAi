import React, { useState, Suspense, lazy } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sidebar, Page } from './components/Sidebar';
import { AuthProvider, useAuth } from './context/AuthContext';
import { RealTimeProvider } from './context/RealTimeContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LoadingSpinner } from './components/LoadingSpinner';
import { LoginPage } from './pages/LoginPage';
import { FileDown, X } from 'lucide-react';
import { usePilotStore } from './store/pilotStore';
import { PilotReportModal } from './components/PilotReportModal';
// Lazy load all pages for better initial load performance
const Dashboard = lazy(() =>
import('./pages/Dashboard').then((module) => ({
  default: module.Dashboard
}))
);
const CongestionForecast = lazy(() =>
import('./pages/CongestionForecast').then((module) => ({
  default: module.CongestionForecast
}))
);
const DispatchOptimization = lazy(() =>
import('./pages/DispatchOptimization').then((module) => ({
  default: module.DispatchOptimization
}))
);
const ScenarioSimulation = lazy(() =>
import('./pages/ScenarioSimulation').then((module) => ({
  default: module.ScenarioSimulation
}))
);
const AIPromptInterface = lazy(() =>
import('./pages/AIPromptInterface').then((module) => ({
  default: module.AIPromptInterface
}))
);
const KPIReporting = lazy(() =>
import('./pages/KPIReporting').then((module) => ({
  default: module.KPIReporting
}))
);
const PlatformBlueprint = lazy(() =>
import('./pages/PlatformBlueprint').then((module) => ({
  default: module.PlatformBlueprint
}))
);
const TotalGeneration = lazy(() =>
import('./pages/TotalGeneration').then((module) => ({
  default: module.TotalGeneration
}))
);
const CurtailmentDetail = lazy(() =>
import('./pages/CurtailmentDetail').then((module) => ({
  default: module.CurtailmentDetail
}))
);
const RevenueDetail = lazy(() =>
import('./pages/RevenueDetail').then((module) => ({
  default: module.RevenueDetail
}))
);
const ForecastAccuracy = lazy(() =>
import('./pages/ForecastAccuracy').then((module) => ({
  default: module.ForecastAccuracy
}))
);
const GenerationVsForecast = lazy(() =>
import('./pages/GenerationVsForecast').then((module) => ({
  default: module.GenerationVsForecast
}))
);
const DispatchStatus = lazy(() =>
import('./pages/DispatchStatus').then((module) => ({
  default: module.DispatchStatus
}))
);
const AIInsights = lazy(() =>
import('./pages/AIInsights').then((module) => ({
  default: module.AIInsights
}))
);
const AllRecommendations = lazy(() =>
import('./pages/AllRecommendations').then((module) => ({
  default: module.AllRecommendations
}))
);
const HyShiftControl = lazy(() =>
import('./pages/HyShiftControl').then((module) => ({
  default: module.HyShiftControl
}))
);
function AuthenticatedApp() {
  const [activePage, setActivePage] = useState<Page>('dashboard');
  const { isAuthenticated } = useAuth();
  const { pilotMode, togglePilotMode, reportOpen, setReportOpen } =
  usePilotStore();
  if (!isAuthenticated) {
    return <LoginPage />;
  }
  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard onNavigate={setActivePage} />;
      case 'congestion':
        return <CongestionForecast onNavigate={setActivePage} />;
      case 'dispatch':
        return <DispatchOptimization onNavigate={setActivePage} />;
      case 'scenario':
        return <ScenarioSimulation onNavigate={setActivePage} />;
      case 'ai-assistant':
        return <AIPromptInterface onNavigate={setActivePage} />;
      case 'kpi':
        return <KPIReporting onNavigate={setActivePage} />;
      case 'blueprint':
        return <PlatformBlueprint onNavigate={setActivePage} />;
      case 'total-generation':
        return <TotalGeneration onNavigate={setActivePage} />;
      case 'curtailment-detail':
        return <CurtailmentDetail onNavigate={setActivePage} />;
      case 'revenue-detail':
        return <RevenueDetail onNavigate={setActivePage} />;
      case 'forecast-accuracy':
        return <ForecastAccuracy onNavigate={setActivePage} />;
      case 'generation-vs-forecast':
        return <GenerationVsForecast onNavigate={setActivePage} />;
      case 'dispatch-status':
        return <DispatchStatus onNavigate={setActivePage} />;
      case 'ai-insights':
        return <AIInsights onNavigate={setActivePage} />;
      case 'all-recommendations':
        return <AllRecommendations onNavigate={setActivePage} />;
      case 'hyshift':
        return <HyShiftControl onNavigate={setActivePage} />;
      default:
        return <Dashboard onNavigate={setActivePage} />;
    }
  };
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans selection:bg-emerald-500/30">
      <Sidebar activePage={activePage} onNavigate={setActivePage} />

      <main className="lg:pl-64 min-h-screen transition-all duration-300 relative">
        {pilotMode &&
        <div className="bg-amber-500/10 border-b border-amber-500/20 text-amber-400 text-xs flex items-center justify-center py-1.5 px-4 relative">
            <span className="font-medium">
              PILOT MODE — Northern Cape Demonstration (Prieska • Kathu •
              Boegoebaai)
            </span>
            <button
            onClick={togglePilotMode}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-amber-500/20 rounded">

              <X className="w-3 h-3" />
            </button>
          </div>
        }

        <ErrorBoundary>
          <Suspense fallback={<LoadingSpinner />}>
            <AnimatePresence mode="wait">
              <motion.div
                key={activePage}
                initial={{
                  opacity: 0,
                  y: 10
                }}
                animate={{
                  opacity: 1,
                  y: 0
                }}
                exit={{
                  opacity: 0,
                  y: -10
                }}
                transition={{
                  duration: 0.2
                }}>

                {renderPage()}
              </motion.div>
            </AnimatePresence>
          </Suspense>
        </ErrorBoundary>

        {pilotMode &&
        <button
          onClick={() => setReportOpen(true)}
          className="fixed bottom-6 right-6 z-40 bg-purple-600 hover:bg-purple-700 text-white p-3 rounded-full shadow-lg transition-colors flex items-center space-x-2 pr-4">

            <FileDown className="w-5 h-5" />
            <span className="font-medium text-sm">Export Pilot Report</span>
          </button>
        }

        <PilotReportModal
          isOpen={reportOpen}
          onClose={() => setReportOpen(false)} />

      </main>
    </div>);

}
export function App() {
  return (
    <AuthProvider>
      <RealTimeProvider>
        <AuthenticatedApp />
      </RealTimeProvider>
    </AuthProvider>);

}