export interface ElectrolyzerStatus {
  loadMW: number;
  productionRate: number; // kg/h
  efficiency: number; // kWh/kg
  lcoh: number; // R/kg
  mode: 'excess' | 'arbitrage' | 'ancillary';
  waterUsage: number; // L/h
  stackTemp: number; // °C
}

export interface CongestionNode {
  name: string;
  currentLoad: number; // %
  forecast24h: number[];
  risk: 'low' | 'medium' | 'high' | 'critical';
}

export interface DispatchCommand {
  id: string;
  timestamp: Date;
  command: string;
  asset: string;
  status: 'pending' | 'executing' | 'executed' | 'failed';
  operator: string;
}

export interface PilotReport {
  date: string;
  curtailmentSaved: number; // MWh
  revenueUplift: number; // ZAR
  h2Produced: number; // kg
  co2Avoided: number; // tons
  gridStabilityScore: number; // 0-100
}

export interface DispatchRecommendation {
  id: number;
  type: 'curtailment' | 'battery' | 'dispatch' | 'hyshift';
  title: string;
  description: string;
  impact: string;
  status: 'pending' | 'approved' | 'rejected';
}

// Mock data fetchers (replace with actual API calls)
export async function fetchElectrolyzerStatus(): Promise<ElectrolyzerStatus> {
  return {
    loadMW: 325,
    productionRate: 420,
    efficiency: 52.4,
    lcoh: 45.2,
    mode: 'excess',
    waterUsage: 3850,
    stackTemp: 72
  };
}

export async function fetchDispatchRecommendations(): Promise<
  DispatchRecommendation[]>
{
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 800));

  return [
  {
    id: 1,
    type: 'curtailment',
    title: 'Curtail Upington Solar',
    description:
    'Reduce output by 15MW during 14:00-16:00 to avoid grid congestion.',
    impact: '+R12,500 revenue preserved',
    status: 'pending'
  },
  {
    id: 2,
    type: 'battery',
    title: 'Battery Charge Cycle',
    description:
    'Charge De Aar BESS at max rate (10MW) from 11:00-13:00 using excess solar.',
    impact: 'Optimize for evening peak',
    status: 'pending'
  },
  {
    id: 3,
    type: 'dispatch',
    title: 'Increase Wind Dispatch',
    description:
    'Ramp up Cookhouse wind farm to 95% capacity for evening peak demand.',
    impact: 'Meet contract obligation',
    status: 'approved'
  },
  {
    id: 4,
    type: 'hyshift',
    title: 'Route 25 MW to Electrolyzer',
    description:
    'Redirect excess solar at Upington (14:00-16:00) to electrolyzer instead of curtailing.',
    impact: 'Avoids curtailment + produces 180 kg H₂',
    status: 'pending'
  }];

}

export async function submitAIPrompt(
prompt: string,
context?: string)
: Promise<{response: string;confidence: number;}> {
  // Simulate AI processing
  await new Promise((resolve) => setTimeout(resolve, 1500));

  return {
    response: `Analysis for "${prompt}": Based on current grid conditions in the Northern Cape, increasing electrolyzer load at Upington would reduce curtailment by 18% while maintaining grid stability within 50.05Hz limits.`,
    confidence: 0.94
  };
}

export async function fetchCongestionNodes(): Promise<CongestionNode[]> {
  return [
  {
    name: 'Upington',
    currentLoad: 87,
    forecast24h: [45, 60, 85, 92, 65, 40],
    risk: 'critical'
  },
  {
    name: 'Prieska',
    currentLoad: 62,
    forecast24h: [30, 45, 62, 58, 42, 28],
    risk: 'medium'
  },
  {
    name: 'Kathu',
    currentLoad: 55,
    forecast24h: [25, 40, 55, 50, 38, 22],
    risk: 'medium'
  },
  {
    name: 'De Aar',
    currentLoad: 58,
    forecast24h: [30, 45, 55, 60, 45, 30],
    risk: 'medium'
  },
  {
    name: 'Boegoebaai',
    currentLoad: 35,
    forecast24h: [20, 30, 35, 32, 25, 18],
    risk: 'low'
  }];

}

export async function generatePilotReport(): Promise<PilotReport> {
  return {
    date: new Date().toISOString().split('T')[0],
    curtailmentSaved: 145,
    revenueUplift: 285000,
    h2Produced: 1240,
    co2Avoided: 28.5,
    gridStabilityScore: 94
  };
}

// Demo mode: simulated real-time updates
export function startDemoStream(
callback: (data: Partial<ElectrolyzerStatus>) => void,
intervalMs = 3000)
: () => void {
  const id = setInterval(() => {
    callback({
      loadMW: 300 + Math.random() * 50,
      productionRate: 400 + Math.random() * 40,
      efficiency: 51 + Math.random() * 3,
      stackTemp: 70 + Math.random() * 5
    });
  }, intervalMs);
  return () => clearInterval(id);
}